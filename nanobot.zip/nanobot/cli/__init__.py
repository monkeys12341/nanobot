"""CLI module for nanobot."""
